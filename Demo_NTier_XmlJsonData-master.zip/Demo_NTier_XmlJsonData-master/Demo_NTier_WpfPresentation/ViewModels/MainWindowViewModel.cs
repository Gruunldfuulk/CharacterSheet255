﻿using Demo_NTier_XmlJsonData.BusinessLayer;
using Demo_NTier_XmlJsonData.Models;
using Demo_NTier_XmlJsonData.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Demo_NTier_XmlJsonData;

namespace Demo_NTier_WpfPresentation.ViewModels
{
    public class MainWindowViewModel : ObservableObject
    {
        private enum OperationStatus
        {
            NONE,
            VIEW,
            ADD,
            EDIT,
            DELETE
        }


        #region COMMANDS

        public ICommand SortCharactersListCommand
        {
            get { return new RelayCommand(new Action<object>(OnSortCharactersList)); }
        }

        public ICommand SearchCharactersListCommand
        {
            get { return new RelayCommand(OnSearchCharactersList); }
        }

        public ICommand AgeFilterCharactersListCommand
        {
            get { return new RelayCommand(OnAgeFilterCharactersList); }
        }

        public ICommand ResetCharactersListCommand
        {
            get { return new RelayCommand(OnResetCharactersList); }
        }

        public ICommand DeleteCharacterCommand
        {
            get { return new RelayCommand(OnDeleteCharacter); }
        }

        public ICommand EditCharacterCommand
        {
            get { return new RelayCommand(OnEditCharacter); }
        }

        public ICommand SaveCharacterCommand
        {
            get { return new RelayCommand(OnSaveCharacter); }
        }

        public ICommand AddCharacterCommand
        {
            get { return new RelayCommand(OnAddCharacter); }
        }

        public ICommand CancelCharacterCommand
        {
            get { return new RelayCommand(OnCancelCharacter); }
        }

        public ICommand ViewCharacterCommand
        {
            get { return new RelayCommand(OnViewCharacter); }
        }

        public ICommand QuitApplicationCommand
        {
            get { return new RelayCommand(OnQuitApplication); }
        }

        #endregion

        #region ENUMS



        #endregion

        #region FIELDS

        private ObservableCollection<DndCharacter> _characters;
        private DndCharacter _selectedCharacter;
        private DndCharacter _detailedViewCharacter;
        private DndCharacterBusiness _fcBusiness;
        private OperationStatus _operationStatus = OperationStatus.NONE;

        private bool _isEditingAdding = false;
        private bool _showAddButton = true;

        private string _sortType;
        private string _searhText;
        private string _minLevelText;
        private string _manLevelText;


        #endregion

        #region PROPERTIES

        public ObservableCollection<DndCharacter> Characters
        {
            get { return _characters; }
            set
            {
                _characters = value;
                OnPropertyChanged(nameof(Characters));
            }
        }

        public DndCharacter DetailedViewCharacter
        {
            get { return _detailedViewCharacter; }
            set
            {
                if (_detailedViewCharacter == value)
                {
                    return;
                }
                _detailedViewCharacter = value;
                OnPropertyChanged("DetailedViewCharacter");
            }
        }

        public DndCharacter SelectedCharacter
        {
            get { return _selectedCharacter; }
            set
            {
                if (_selectedCharacter == value)
                {
                    return;
                }
                _selectedCharacter = value;
                OnPropertyChanged("SelectedCharacter");
            }
        }

        public bool IsEditingAdding
        {
            get { return _isEditingAdding; }
            set
            {
                _isEditingAdding = value;
                OnPropertyChanged(nameof(IsEditingAdding));
            }
        }

        public bool ShowAddButton
        {
            get { return _showAddButton; }
            set
            {
                _showAddButton = value;
                OnPropertyChanged(nameof(ShowAddButton));
            }
        }

        public string SortType
        {
            get { return _sortType; }
            set { _sortType = value; }
        }

        public string SearchText
        {
            get { return _searhText; }
            set
            {
                _searhText = value;
                OnPropertyChanged(nameof(SearchText));
            }
        }


        public string MaxLevelText
        {
            get { return _manLevelText; }
            set
            {
                _manLevelText = value;
                OnPropertyChanged(nameof(MaxLevelText));
            }
        }


        public string MinLevelText
        {
            get { return _minLevelText; }
            set
            {
                _minLevelText = value;
                OnPropertyChanged(nameof(MinLevelText));
            }
        }

        #endregion

        #region CONSTRUCTORS

        public MainWindowViewModel(DndCharacterBusiness fcBusiness)
        {
            _fcBusiness = fcBusiness;
            _characters = new ObservableCollection<DndCharacter>(_fcBusiness.AllDndCharacters());
            UpdateImagePath();
        }

        #endregion

        #region METHODS

        private void UpdateImagePath()
        {
            foreach (var character in _characters)
            {
                character.ImageFilePath = DataConfig.ImagePath + character.ImageFileName;
            }
        }


        private void OnDeleteCharacter()
        {
            if (_selectedCharacter != null)
            {
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show($"Are you sure you want to delete {_selectedCharacter.FullName}?", "Delete Character", System.Windows.MessageBoxButton.OKCancel);

                if (messageBoxResult == MessageBoxResult.OK)
                {
                    //
                    // delete character from persistence
                    //
                    _fcBusiness.DeleteDndCharacter(SelectedCharacter.Id);

                    //
                    // remove character from list - update view
                    //
                    _characters.Remove(_selectedCharacter);
                }
            }
        }

        private void OnEditCharacter()
        {
            if (_selectedCharacter != null)
            {
                _operationStatus = OperationStatus.EDIT;
                IsEditingAdding = true;
                ShowAddButton = false;
                UpdateDetailedViewCharacterToSelected();
            }
        }

        private void OnViewCharacter()
        {
            if (_selectedCharacter != null)
            {
                _operationStatus = OperationStatus.VIEW;
                UpdateDetailedViewCharacterToSelected();
            }
        }

        private void OnAddCharacter()
        {
            ResetDetailedViewCharacter();
            IsEditingAdding = true;
            ShowAddButton = false;
            _operationStatus = OperationStatus.ADD;
        }

        private void OnSaveCharacter()
        {
            switch (_operationStatus)
            {
                case OperationStatus.ADD:
                    if (_detailedViewCharacter != null)
                    {
                        //
                        // add character to persistence
                        //
                        _fcBusiness.AddDndCharacter(_detailedViewCharacter);

                        //
                        // add character to list - update view
                        //
                        _characters.Add(DetailedViewCharacter);
                    }
                    break;
                case OperationStatus.EDIT:
                    DndCharacter characterToUpdate = _characters.FirstOrDefault(c => c.Id == SelectedCharacter.Id);

                    if (characterToUpdate != null)
                    {
                        //
                        // update character in persistence
                        //
                        _fcBusiness.UpdateDndCharacter(DetailedViewCharacter);

                        //
                        // update character in list - update view
                        _characters.Remove(characterToUpdate);
                        _characters.Add(DetailedViewCharacter);
                    }
                    break;
                default:
                    break;
            }

            ResetDetailedViewCharacter();
            IsEditingAdding = false;
            ShowAddButton = true;
            _operationStatus = OperationStatus.NONE;
        }

        private void OnCancelCharacter()
        {
            ResetDetailedViewCharacter();
            _operationStatus = OperationStatus.NONE;
            IsEditingAdding = false;
            ShowAddButton = true;
        }

        private void UpdateDetailedViewCharacterToSelected()
        {
            _detailedViewCharacter = new DndCharacter();
            _detailedViewCharacter.Id = _selectedCharacter.Id;
            _detailedViewCharacter.FirstName = _selectedCharacter.FirstName;
            _detailedViewCharacter.LastName = _selectedCharacter.LastName;
            _detailedViewCharacter.ClassType = _selectedCharacter.ClassType;
            _detailedViewCharacter.Background = _selectedCharacter.Background;
            _detailedViewCharacter.Alignment = _selectedCharacter.Alignment;
            _detailedViewCharacter.Race = _selectedCharacter.Race;
            _detailedViewCharacter.Age = _selectedCharacter.Age;
            _detailedViewCharacter.Gender = _selectedCharacter.Gender;
            _detailedViewCharacter.Eyes = _selectedCharacter.Eyes;
            _detailedViewCharacter.Hair = _selectedCharacter.Hair;
            _detailedViewCharacter.Height = _selectedCharacter.Height;
            _detailedViewCharacter.Weight = _selectedCharacter.Weight;

            _detailedViewCharacter.CurrentGold = _selectedCharacter.CurrentGold;

            _detailedViewCharacter.Strength = _selectedCharacter.Strength;
            _detailedViewCharacter.Dexterity = _selectedCharacter.Dexterity;
            _detailedViewCharacter.Constitution = _selectedCharacter.Constitution;
            _detailedViewCharacter.Intelligence = _selectedCharacter.Intelligence;
            _detailedViewCharacter.Wisdom = _selectedCharacter.Wisdom;
            _detailedViewCharacter.Charisma = _selectedCharacter.Charisma;

            _detailedViewCharacter.Acrobatics = _selectedCharacter.Acrobatics;
            _detailedViewCharacter.AnimalHandling = _selectedCharacter.AnimalHandling;
            _detailedViewCharacter.Arcana = _selectedCharacter.Arcana;
            _detailedViewCharacter.Athletics = _selectedCharacter.Athletics;
            _detailedViewCharacter.Deception = _selectedCharacter.Deception;
            _detailedViewCharacter.History = _selectedCharacter.History;
            _detailedViewCharacter.Insight = _selectedCharacter.Insight;
            _detailedViewCharacter.Intimidation = _selectedCharacter.Intimidation;
            _detailedViewCharacter.Investigation = _selectedCharacter.Investigation;
            _detailedViewCharacter.Medicine = _selectedCharacter.Medicine;
            _detailedViewCharacter.Nature = _selectedCharacter.Nature;
            _detailedViewCharacter.Perception = _selectedCharacter.Perception;
            _detailedViewCharacter.Performance = _selectedCharacter.Performance;
            _detailedViewCharacter.Persuasion = _selectedCharacter.Persuasion;
            _detailedViewCharacter.Religion = _selectedCharacter.Religion;
            _detailedViewCharacter.SleightOfHand = _selectedCharacter.SleightOfHand;
            _detailedViewCharacter.Stealth = _selectedCharacter.Stealth;
            _detailedViewCharacter.Survival = _selectedCharacter.Survival;

            _detailedViewCharacter.ArmorClass = _selectedCharacter.ArmorClass;
            _detailedViewCharacter.Initiative = _selectedCharacter.Initiative;
            _detailedViewCharacter.Speed = _selectedCharacter.Speed;
            _detailedViewCharacter.MaxHealth = _selectedCharacter.MaxHealth;
            _detailedViewCharacter.CurrentHealth = _selectedCharacter.CurrentHealth;

            _detailedViewCharacter.Level = _selectedCharacter.Level;
            _detailedViewCharacter.Description = _selectedCharacter.Description;
            _detailedViewCharacter.ImageFileName = _selectedCharacter.ImageFileName;
            _detailedViewCharacter.ImageFilePath = _selectedCharacter.ImageFilePath;
            _detailedViewCharacter.ItemList = _selectedCharacter.ItemList;
            OnPropertyChanged("DetailedViewCharacter");
        }

        private void ResetDetailedViewCharacter()
        {
            _detailedViewCharacter = new DndCharacter();
            _detailedViewCharacter.FirstName = "";
            _detailedViewCharacter.LastName = "";
            _detailedViewCharacter.ClassType = "";
            _detailedViewCharacter.Background = "";
            _detailedViewCharacter.Alignment = "";
            _detailedViewCharacter.Race = DndCharacter.RaceType.Human;
            _detailedViewCharacter.Age = 0;
            _detailedViewCharacter.Gender = DndCharacter.GenderType.None;
            _detailedViewCharacter.Eyes = "";
            _detailedViewCharacter.Hair = "";
            _detailedViewCharacter.Height = 0;
            _detailedViewCharacter.Weight = 0;
            _detailedViewCharacter.CurrentGold = 0;

            _detailedViewCharacter.Strength = 0;
            _detailedViewCharacter.Dexterity = 0;
            _detailedViewCharacter.Constitution = 0;
            _detailedViewCharacter.Intelligence = 0;
            _detailedViewCharacter.Wisdom = 0;
            _detailedViewCharacter.Charisma = 0;

            _detailedViewCharacter.Acrobatics = 0;
            _detailedViewCharacter.AnimalHandling = 0;
            _detailedViewCharacter.Arcana = 0;
            _detailedViewCharacter.Athletics = 0;
            _detailedViewCharacter.Deception = 0;
            _detailedViewCharacter.History = 0;
            _detailedViewCharacter.Insight = 0;
            _detailedViewCharacter.Intimidation = 0;
            _detailedViewCharacter.Investigation = 0;
            _detailedViewCharacter.Medicine = 0;
            _detailedViewCharacter.Nature = 0;
            _detailedViewCharacter.Perception = 0;
            _detailedViewCharacter.Performance = 0;
            _detailedViewCharacter.Persuasion = 0;
            _detailedViewCharacter.Religion = 0;
            _detailedViewCharacter.SleightOfHand = 0;
            _detailedViewCharacter.Stealth = 0;
            _detailedViewCharacter.Survival = 0;

            _detailedViewCharacter.ArmorClass = 10;
            _detailedViewCharacter.Initiative = 0;
            _detailedViewCharacter.Speed = 30;
            _detailedViewCharacter.MaxHealth = 1;
            _detailedViewCharacter.CurrentHealth = 1;

            _detailedViewCharacter.Level = 1;
            _detailedViewCharacter.Description = "";
            _detailedViewCharacter.ImageFileName = "";
            _detailedViewCharacter.ImageFilePath = "";
            
            OnPropertyChanged("DetailedViewCharacter");
        }

        private void OnQuitApplication()
        {
            //
            // call a house keeping method in the business class
            //
            System.Environment.Exit(1);
        }

        private void OnSortListByLevel()
        {
            Characters = new ObservableCollection<DndCharacter>(_characters.OrderBy(c => c.Level));
        }


        private void OnSortCharactersList(object obj)
        {
            string sortType = obj.ToString();
            switch (sortType)
            {
                case "Level":
                    Characters = new ObservableCollection<DndCharacter>(Characters.OrderBy(c => c.Level));
                    break;

                case "LastName":
                    Characters = new ObservableCollection<DndCharacter>(Characters.OrderBy(c => c.LastName));
                    break;

                default:
                    break;
            }

        }

        private void OnSearchCharactersList()
        {
            //
            // reset age filters
            //
            MinLevelText = "";
            MaxLevelText = "";

            //
            // reset to full list before search
            //
            _characters = new ObservableCollection<DndCharacter>(_fcBusiness.AllDndCharacters());
            UpdateImagePath();

            Characters = new ObservableCollection<DndCharacter>(_characters.Where(c => c.LastName.ToLower().Contains(_searhText)));
        }

        private void OnAgeFilterCharactersList()
        {
            //
            // reset search text box
            //
            SearchText = "";

            if (int.TryParse(MinLevelText, out int minLevel) && int.TryParse(MaxLevelText, out int maxLevel))
            {
                //
                // reset to full list before search
                //
                _characters = new ObservableCollection<DndCharacter>(_fcBusiness.AllDndCharacters());
                UpdateImagePath();

                Characters = new ObservableCollection<DndCharacter>(_characters.Where(c => c.Level >= minLevel && c.Level <= maxLevel));
            }
        }

        private void OnResetCharactersList()
        {
            //
            // reset search and filter text boxes
            //
            SearchText = "";
            MinLevelText = "";
            MaxLevelText = "";

            //
            // reset to full list 
            //
            _characters = new ObservableCollection<DndCharacter>(_fcBusiness.AllDndCharacters());
            UpdateImagePath();

            Characters = _characters;
        }

        #endregion

        #region EVENTS


        #endregion


    }
}
