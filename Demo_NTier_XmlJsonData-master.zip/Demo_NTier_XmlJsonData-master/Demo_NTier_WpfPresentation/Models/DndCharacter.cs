﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Demo_NTier_XmlJsonData;
using System.ComponentModel;

namespace Demo_NTier_XmlJsonData.Models
{
    public class DndCharacter : ObservableObject
    {
        #region ENUMS

        public enum GenderType { None, Male, Female }

        public enum RaceType { Human, Elf, Drawf, Halfling, Gnome, HalfElf, HalfOrc, Tiefling, Dragonborn }
        #endregion

        #region FIELDS

        private int _id;

        //Bio//
        private string _firstName;
        private string _lastName;
        private string _classType;
        private string _background;
        private int _age;
        private string _description;
        private GenderType _gender;
        private RaceType _race;
        private string _alignment;
        private string _eyes;
        private string _hair;
        private int _height;
        private int _weight;

        //Stats//
        private int _str;
        private int _dex;
        private int _con;
        private int _int;
        private int _wis;
        private int _cha;

        //Skills//

        private int _acrobatics;
        private int _animalHandling;
        private int _arcana;
        private int _athletics;
        private int _deception;
        private int _history;
        private int _insight;
        private int _intimidation;
        private int _investigation;
        private int _medicine;
        private int _nature;
        private int _perception;
        private int _performance;
        private int _persuasion;
        private int _religion;
        private int _sleightOfHand;
        private int _stealth;
        private int _survival;



        //Other Stats//
        private int _level;
        private double _currentGold;
        private List<Inventory> _itemList;
        private int _armorClass;
        private int _speed;
        private int _maxHealth;
        private int _currentHealth;
        private int _initiative;

            

        //img//
        private string _imageFileName;
        private string _imageFilePath;
        #endregion

        #region PROPERTIES

        public int Id
        {
            get { return _id; }
            set
            {
                _id = value;
                OnPropertyChanged(nameof(Id));
            }
        }

        public string FirstName
        {
            get { return _firstName; }
            set
            {
                _firstName = value;
                OnPropertyChanged(nameof(FirstName));
                OnPropertyChanged(nameof(FullName));
            }
        }

        public string LastName
        {
            get { return _lastName; }
            set
            {
                _lastName = value;
                OnPropertyChanged(nameof(LastName));
                OnPropertyChanged(nameof(FullName));
            }
        }
        public string ClassType
        {
            get { return _classType; }
            set
            {
                _classType = value;
                OnPropertyChanged(nameof(ClassType));
            }
        }
        public string Alignment
        {
            get { return _alignment; }
            set
            {
                _alignment = value;
                OnPropertyChanged(nameof(Alignment));
            }
        }
        public string Background
        {
            get { return _background; }
            set
            {
                _background = value;
                OnPropertyChanged(nameof(Background));
            }
        }

        public int Age
        {
            get { return _age; }
            set
            {
                _age = value;
                OnPropertyChanged(nameof(Age));
            }
        }
        public string Eyes
        {
            get { return _eyes; }
            set
            {
                _eyes = value;
                OnPropertyChanged(nameof(Eyes));
            }
        }
        public string Hair
        {
            get { return _hair; }
            set
            {
                _hair = value;
                OnPropertyChanged(nameof(Hair));
            }
        }
        public int Height
        {
            get { return _height; }
            set
            {
                _height = value;
                OnPropertyChanged(nameof(Height));
            }
        }
        public int Weight
        {
            get { return _weight; }
            set
            {
                _weight = value;
                OnPropertyChanged(nameof(Weight));
            }
        }

        //Stats//

        public int Strength
        {
            get { return _str; }
            set
            {
                _str = value;
                OnPropertyChanged(nameof(Strength));
            }
        }
        public int Dexterity
        {
            get { return _dex; }
            set
            {
                _dex = value;
                OnPropertyChanged(nameof(Dexterity));
            }
        }
        public int Constitution
        {
            get { return _con; }
            set
            {
                _con = value;
                OnPropertyChanged(nameof(Constitution));
            }
        }
        public int Intelligence
        {
            get { return _int; }
            set
            {
                _int = value;
                OnPropertyChanged(nameof(Intelligence));
            }
        }
        public int Wisdom
        {
            get { return _wis; }
            set
            {
                _wis = value;
                OnPropertyChanged(nameof(Wisdom));
            }
        }
        public int Charisma
        {
            get { return _cha; }
            set
            {
                _cha = value;
                OnPropertyChanged(nameof(Charisma));
            }
        }

        //skills//
        public int Acrobatics
        {
            get { return _acrobatics; }
            set
            {
                _acrobatics = value;
                OnPropertyChanged(nameof(Acrobatics));
            }
        }
        public int AnimalHandling
        {
            get { return _animalHandling; }
            set
            {
                _animalHandling = value;
                OnPropertyChanged(nameof(AnimalHandling));
            }
        }
        public int Arcana
        {
            get { return _arcana; }
            set
            {
                _arcana = value;
                OnPropertyChanged(nameof(Arcana));
            }
        }
        public int Athletics
        {
            get { return _athletics; }
            set
            {
                _athletics = value;
                OnPropertyChanged(nameof(Athletics));
            }
        }
        public int Deception
        {
            get { return _deception; }
            set
            {
                _deception = value;
                OnPropertyChanged(nameof(Deception));
            }
        }
        public int History
        {
            get { return _history; }
            set
            {
                _history = value;
                OnPropertyChanged(nameof(History));
            }
        }
        public int Insight
        {
            get { return _insight; }
            set
            {
                _insight = value;
                OnPropertyChanged(nameof(Insight));
            }
        }
        public int Intimidation
        {
            get { return _intimidation; }
            set
            {
                _intimidation = value;
                OnPropertyChanged(nameof(Intimidation));
            }
        }
        public int Investigation
        {
            get { return _investigation; }
            set
            {
                _investigation = value;
                OnPropertyChanged(nameof(Investigation));
            }
        }
        public int Medicine
        {
            get { return _medicine; }
            set
            {
                _medicine = value;
                OnPropertyChanged(nameof(Medicine));
            }
        }
        public int Nature
        {
            get { return _nature; }
            set
            {
                _nature = value;
                OnPropertyChanged(nameof(Nature));
            }
        }
        public int Perception
        {
            get { return _perception; }
            set
            {
                _perception = value;
                OnPropertyChanged(nameof(Perception));
            }
        }
        public int Performance
        {
            get { return _performance; }
            set
            {
                _performance = value;
                OnPropertyChanged(nameof(Performance));
            }
        }
        public int Persuasion
        {
            get { return _persuasion; }
            set
            {
                _persuasion = value;
                OnPropertyChanged(nameof(Persuasion));
            }
        }
        public int Religion
        {
            get { return _religion; }
            set
            {
                _religion = value;
                OnPropertyChanged(nameof(Religion));
            }
        }
        public int SleightOfHand
        {
            get { return _sleightOfHand; }
            set
            {
                _sleightOfHand = value;
                OnPropertyChanged(nameof(SleightOfHand));
            }
        }
        public int Stealth
        {
            get { return _stealth; }
            set
            {
                _stealth = value;
                OnPropertyChanged(nameof(Stealth));
            }
        }
        public int Survival
        {
            get { return _survival; }
            set
            {
                _survival = value;
                OnPropertyChanged(nameof(Survival));
            }
        }


        //other stats//
        public int ArmorClass
        {
            get { return _armorClass; }
            set
            {
                _armorClass = value;
                OnPropertyChanged(nameof(ArmorClass));
            }
        }
        public int Speed
        {
            get { return _speed; }
            set
            {
                _speed = value;
                OnPropertyChanged(nameof(Speed));
            }
        }
        public int MaxHealth
        {
            get { return _maxHealth; }
            set
            {
                _maxHealth = value;
                OnPropertyChanged(nameof(MaxHealth));
            }
        }
        public int CurrentHealth
        {
            get { return _currentHealth; }
            set
            {
                _currentHealth = value;
                OnPropertyChanged(nameof(CurrentHealth));
            }
        }
        public int Initiative
        {
            get { return _initiative; }
            set
            {
                _initiative = value;
                OnPropertyChanged(nameof(Initiative));
            }
        }


        //Bio//
        public GenderType Gender
        {
            get { return _gender; }
            set
            {
                _gender = value;
                OnPropertyChanged(nameof(Gender));
            }
        }

        public RaceType Race
        {
            get { return _race; }
            set
            {
                _race = value;
                OnPropertyChanged(nameof(Race));
            }
        }

        public string ImageFileName
        {
            get { return _imageFileName; }
            set
            {
                _imageFileName = value;
                OnPropertyChanged(nameof(ImageFileName));
            }
        }

        public string Description
        {
            get { return _description; }
            set
            {
                _description = value;
                OnPropertyChanged(nameof(Description));
            }
        }

        public int Level
        {
            get { return _level; }
            set
            {
                _level = value;
                OnPropertyChanged(nameof(Level));
            }
        }

        public double CurrentGold
        {
            get { return _currentGold; }
            set
            {
                _currentGold = value;
                OnPropertyChanged(nameof(CurrentGold));
            }
        }

        public string FullName
        {
            get { return _firstName + " " + _lastName; }
        }

        public string ImageFilePath
        {
            get { return _imageFilePath; }
            set
            {
                _imageFilePath = value;
                OnPropertyChanged(nameof(ImageFilePath));
            }
        }

        public List<Inventory> ItemList
        {
            get { return _itemList; }
            set { _itemList = value; }
        }

        #endregion

        #region CONSTRUCTORS

        public DndCharacter()
        {

        }

        #endregion

        #region METHODS


        #endregion

        #region EVENTS



        #endregion

    }
}
