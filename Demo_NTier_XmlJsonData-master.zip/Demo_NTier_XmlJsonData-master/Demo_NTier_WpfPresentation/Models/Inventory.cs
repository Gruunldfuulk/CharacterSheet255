﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Demo_NTier_XmlJsonData.Models
{
    public class Inventory
    {
        public string Name { get; set; }

        public int Quantity { get; set; }
    }
}
