﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Demo_NTier_XmlJsonData.Models;
using Demo_NTier_XmlJsonData.DataAccessLayer;

namespace Demo_NTier_XmlJsonData.BusinessLayer
{
    public class DndCharacterBusiness
    {
        public FileIoMessage FileIoStatus { get; set; }

        public DndCharacterBusiness()
        {

        }

        /// <summary>
        /// retrieve a character using the repository
        /// </summary>
        /// <returns>character</returns>
        private DndCharacter GetCharacter(int id)
        {
            DndCharacter character = null;
            FileIoStatus = FileIoMessage.None;

            try
            {
                using (DndCharacterRepository fsRepository = new DndCharacterRepository())
                {
                    character = fsRepository.GetById(id);
                };

                if (character != null)
                {
                    FileIoStatus = FileIoMessage.Complete;
                }
                else
                {
                    FileIoStatus = FileIoMessage.RecordNotFound;
                }
            }
            catch (Exception)
            {
                FileIoStatus = FileIoMessage.FileAccessError;
            }

            return character;
        }

        /// <summary>
        /// retrieve a list of all characters using the repository
        /// </summary>
        /// <returns>all characters</returns>
        private List<DndCharacter> GetAllCharacters()
        {
            List<DndCharacter> characters = null;
            FileIoStatus = FileIoMessage.None;

            try
            {
                using (DndCharacterRepository fsRepository = new DndCharacterRepository())
                {
                    characters = fsRepository.GetAll() as List<DndCharacter>;
                };

                if (characters != null)
                {
                    FileIoStatus = FileIoMessage.Complete;
                }
                else
                {
                    FileIoStatus = FileIoMessage.NoRecordsFound;
                }
            }
            catch (Exception)
            {
                FileIoStatus = FileIoMessage.FileAccessError;
            }

            return characters;
        }

        /// <summary>
        /// provide a list of all characters
        /// </summary>
        /// <returns>list of all characters</returns>
        public List<DndCharacter> AllDndCharacters()
        {
            return GetAllCharacters() as List<DndCharacter>;
        }

        /// <summary>
        /// retrieve a character by id 
        /// </summary>
        /// <param name="id">character id</param>
        /// <returns>character</returns>
        public DndCharacter DndCharacterById(int id)
        {
            return GetCharacter(id);
        }

        /// <summary>
        /// add a new character
        /// </summary>
        /// <param name="character">character to add</param>
        public void AddDndCharacter(DndCharacter character)
        {
            try
            {
                if (character != null)
                {
                    using (DndCharacterRepository fsRepository = new DndCharacterRepository())
                    {
                        fsRepository.Add(character);
                    };

                    FileIoStatus = FileIoMessage.Complete;
                }
            }
            catch (Exception)
            {
                FileIoStatus = FileIoMessage.FileAccessError;
            }
        }

        /// <summary>
        /// retrieve a character by id 
        /// </summary>
        /// <param name="id">character id</param>
        public void DeleteDndCharacter(int id)
        {
            try
            {
                if (GetCharacter(id) != null)
                {
                    using (DndCharacterRepository repo = new DndCharacterRepository())
                    {
                        repo.Delete(id);
                    }

                    FileIoStatus = FileIoMessage.Complete;
                }
                else
                {
                    FileIoStatus = FileIoMessage.RecordNotFound;
                }
            }
            catch (Exception)
            {
                FileIoStatus = FileIoMessage.FileAccessError;
            }
        }
        public void UpdateDndCharacter(DndCharacter updatedCharacter)
        {
            try
            {
                if (GetCharacter(updatedCharacter.Id) != null)
                {
                    using (DndCharacterRepository repo = new DndCharacterRepository())
                    {
                        repo.Update(updatedCharacter);
                    }

                    FileIoStatus = FileIoMessage.Complete;
                }
                else
                {
                    FileIoStatus = FileIoMessage.RecordNotFound;
                }
            }
            catch (Exception)
            {
                FileIoStatus = FileIoMessage.FileAccessError;
            }
        }

    }
}
