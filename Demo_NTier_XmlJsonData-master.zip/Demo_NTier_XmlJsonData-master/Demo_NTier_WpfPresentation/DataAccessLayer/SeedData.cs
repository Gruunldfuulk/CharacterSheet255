﻿using Demo_NTier_XmlJsonData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_NTier_XmlJsonData.DataAccessLayer
{
    public class SeedData
    {
        public static List<DndCharacter> GenerateListOfCharacters()
        {
            List<DndCharacter> characters = new List<DndCharacter>()
            {
                new DndCharacter()
                {
                    Id = 1,
                    ImageFileName = "valmaxian_vance.jpg",
                    LastName = "Vance",
                    FirstName = "Valmaxian",
                    Level = 5,
                    ClassType = "Wizard",
                    Background = "Noble",
                    Alignment = "NG",
                    Race = DndCharacter.RaceType.HalfElf,
                    Age = 26,
                    Eyes = "Blue",
                    Hair = "Black",
                    Height = 170,
                    Weight = 50,
                    
                    //
                    //Stat block
                    //
                    Strength = 8,
                    Dexterity = 14,
                    Constitution = 14,
                    Intelligence = 18,
                    Wisdom = 12,
                    Charisma = 10,

                    //Skills//
                    Acrobatics = 2,
                    AnimalHandling = 1,
                    Arcana = 7,
                    Athletics = -1,
                    Deception = 0,
                    History = 7,
                    Insight = 1,
                    Intimidation = 0,
                    Investigation = 7,
                    Medicine = 1,
                    Nature = 4,
                    Perception = 1,
                    Performance = 0,
                    Persuasion = 3,
                    Religion = 4,
                    SleightOfHand = 2,
                    Stealth = 2,
                    Survival = 1,

                    //Other Stats//
                    ArmorClass = 12,
                    Initiative = 2,
                    Speed = 30,
                    MaxHealth = 32,
                    CurrentHealth = 32,


            Description = "A half-elf wizard on the hunt for a spell to change memories. He plans to train and travel the Swordcoast to improve his skills and gain knowledge. He has a fear of fire, due to his right arm being burned at a young age. However he is skilled in magic that controls the people and world around him, without the need for direct damage.",
                    Gender = DndCharacter.GenderType.Male,
                    ItemList = new List<Inventory>()
                    {
                        new Inventory()
                        {
                            Name = "50ft of Rope",
                            Quantity = 1
                        },
                        new Inventory()
                        {
                            Name = "Sheet of Parchment",
                            Quantity = 10
                        },
                        new Inventory()
                        {
                            Name = "Ink Pen",
                            Quantity = 1
                        },
                        new Inventory()
                        {
                            Name = "Bottle of Ink",
                            Quantity = 1
                        }
                    }
                },
                new DndCharacter()
                {
                    Id = 2,
                    ImageFileName = "roland_d'cannith.png",
                    LastName = "D'Cannith",
                    FirstName = "Roland",
                    Level = 9,
                    ClassType = "Artificer",
                    Background = "Sage",
                    Alignment = "N",
                    Race = DndCharacter.RaceType.Human,
                    Age = 24,
                    Eyes = "White",
                    Hair = "Black",
                    Height = 179,
                    Weight = 69,
                    
                    //
                    //Stat block
                    //
                    Strength = 12,
                    Dexterity = 18,
                    Constitution = 15,
                    Intelligence = 20,
                    Wisdom = 15,
                    Charisma = 11,

                    //Skills//
                    Acrobatics = 4,
                    AnimalHandling = 2,
                    Arcana = 9,
                    Athletics = 1,
                    Deception = 0,
                    History = 9,
                    Insight = 2,
                    Intimidation = 0,
                    Investigation = 9,
                    Medicine = 2,
                    Nature = 5,
                    Perception = 6,
                    Performance = 0,
                    Persuasion = 0,
                    Religion = 5,
                    SleightOfHand = 4,
                    Stealth = 8,
                    Survival = 2,

                    //Other Stats//
                    ArmorClass = 19,
                    Initiative = 4,
                    Speed = 30,
                    MaxHealth = 62,
                    CurrentHealth = 62,

                    Description = "Human builder and crafter of weapons from the city of undead. Using firearms and tools to change combat to help his allies. He hopes to uncover the those in the government that would try to take power and using his tools for their own ends.",
                    Gender = DndCharacter.GenderType.Male,
                    ItemList = new List<Inventory>()
                    {
                        new Inventory()
                        {
                            Name = "50ft of Rope",
                            Quantity = 1
                        },
                        new Inventory()
                        {
                            Name = "Tables of Writing",
                            Quantity = 2
                        },
                        new Inventory()
                        {
                            Name = "Bag of Holding",
                            Quantity = 1
                        },
                        new Inventory()
                        {
                            Name = "Sending Stone",
                            Quantity = 1
                        }
                    }
                },
                new DndCharacter()
                {
                    Id = 3,
                    ImageFileName = "etgar_heiral.jpg",
                    LastName = "Heiral",
                    FirstName = "Etgar",
                    Level = 8,
                    ClassType = "Rouge",
                    Background = "Bounty Hunter",
                    Alignment = "LN",
                    Race = DndCharacter.RaceType.Human,
                    Age = 20,
                    Eyes = "Brown",
                    Hair = "Brown",
                    Height = 180,
                    Weight = 60,
                    
                    //
                    //Stat block
                    //
                    Strength = 10,
                    Dexterity = 20,
                    Constitution = 14,
                    Intelligence = 14,
                    Wisdom = 16,
                    Charisma = 12,

                    //Skills//
                    Acrobatics = 5,
                    AnimalHandling = 3,
                    Arcana = 2,
                    Athletics = 0,
                    Deception = 1,
                    History = 2,
                    Insight = 3,
                    Intimidation = 1,
                    Investigation = 3,
                    Medicine = 3,
                    Nature = 2,
                    Perception = 9,
                    Performance = 1,
                    Persuasion = 1,
                    Religion = 2,
                    SleightOfHand = 11,
                    Stealth = 11,
                    Survival = 3,

                    //Other Stats//
                    ArmorClass = 18,
                    Initiative = 10,
                    Speed = 30,
                    MaxHealth = 65,
                    CurrentHealth = 65,

                    Description = "Raised in a family of assassins he was set to take over the family. But he wanted to go out and make a name for himself, making friends, co-owning a bar, and diving into the endless maze under the city.",
                    Gender = DndCharacter.GenderType.Male,
                    ItemList = new List<Inventory>()
                    {
                        new Inventory()
                        {
                            Name = "50ft of Rope",
                            Quantity = 1
                        },
                        new Inventory()
                        {
                            Name = "Cloak of the Bat",
                            Quantity = 2
                        },
                        new Inventory()
                        {
                            Name = "Bag of Holding",
                            Quantity = 1
                        },
                        new Inventory()
                        {
                            Name = "Bracers of flying Daggers",
                            Quantity = 1
                        }
                    }
                }
            };

            return characters;
        }
    }
}
